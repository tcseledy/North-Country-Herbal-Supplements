const https = require('https');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');
const argon2 = require('argon2');

// 1. SSL/TLS Keys Handshake
const options = {
  key: fs.readFileSync(path.join(__dirname, 'server.key')),
  cert: fs.readFileSync(path.join(__dirname, 'server.crt'))
};

// 2. Establish Secure MySQL Database Connection Pool
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',          // Replace with your MySQL Username
  password: 'harry123',  // Replace with your MySQL Password
  database: 'north_country_shop',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const server = https.createServer(options, (req, res) => {
  
  // --- ENDPOINT 1: Secure Account Registration (Sign-Up) ---
  if (req.url === '/api/signup' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', async () => {
      try {
        const { name, email, password } = JSON.parse(body);

        // Security Parameter: Hash the plain-text password using argon2id
        const passwordHash = await argon2.hash(password, { type: argon2.argon2id });

        // SQL Injection Guard: Use prepared parameterized statements
        const checkSql = 'SELECT id FROM users WHERE email = ?';
        db.execute(checkSql, [email], (err, results) => {
          if (err) throw err;
          
          if (results.length > 0) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, message: 'Email already registered!' }));
          }

          const insertSql = 'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)';
          db.execute(insertSql, [name, email, passwordHash], (err, insertResult) => {
            if (err) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ success: false, message: 'Database write error.' }));
            }

            console.log(`👤 MySQL Registered: ${name} (${email})`);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, message: 'Account securely saved to MySQL!' }));
          });
        });

      } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, message: 'Server security encryption failure.' }));
      }
    });
    return;
  }

  // --- ENDPOINT 2: Secure Identity Verification (Log-In) ---
  if (req.url === '/api/login' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        const { email, password } = JSON.parse(body);

        const loginSql = 'SELECT name, email, password_hash FROM users WHERE email = ?';
        db.execute(loginSql, [email], async (err, results) => {
          if (err) throw err;

          if (results.length === 0) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, message: 'Invalid email or password!' }));
          }

          const user = results[0];

          // Argon2 Secure Verification: Compares input with saved hash
          const passwordMatches = await argon2.verify(user.password_hash, password);

          if (!passwordMatches) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, message: 'Invalid email or password!' }));
          }

          console.log(`🔒 Secure MySQL Verification: ${user.name} logged in`);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            success: true,
            message: 'Authenticated successfully!',
            user: { name: user.name, email: user.email }
          }));
        });

      } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, message: 'Authentication process failure.' }));
      }
    });
    return;
  }

  // --- ENDPOINT 3: Static File Server Router ---
  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
  const extname = String(path.extname(filePath)).toLowerCase();
  
  const mimeTypes = {
    '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript',
    '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg'
  };

  const contentType = mimeTypes[extname] || 'application/octet-stream';

  fs.readFile(filePath, (error, content) => {
    if (error) {
      if (error.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 File Not Found</h1>', 'utf-8');
      } else {
        res.writeHead(500); res.end(`Server Error: ${error.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType }); res.end(content, 'utf-8');
    }
  });
});

const PORT = 8442;
server.listen(PORT, () => {
  console.log(`🔒 Production-Grade MySQL/Argon2id Server running on: https://localhost:${PORT}`);
});